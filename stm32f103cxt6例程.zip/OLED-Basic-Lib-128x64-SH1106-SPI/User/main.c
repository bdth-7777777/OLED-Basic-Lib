#include "OLED.h"
#include "Timer.h"
uint16_t FPS = 0;
uint16_t FPS_Counter = 0;



int main(){
	Timer_Init();
	OLED_Init();

	
	while(1){
		OLED_Clear();
		OLED_Printf(0,0,OLED_FONT_8,"Hello World!");
		OLED_Printf(0,10,OLED_FONT_8,"Hello %2d",-10);
		OLED_Printf(0,20,OLED_FONT_8,"Hello %3.2f",5.123);
		OLED_Printf(0,30,OLED_FONT_8,"Hello %c",'a');
		OLED_Printf(0,40,OLED_FONT_8,"Hello %s",(char*)"World");
		if(OLED_IfChangedScreen()){
			FPS_Counter++;
		}
		OLED_Printf(0,50,OLED_FONT_8,"FPS:%d",FPS);
		OLED_Update();
	}
}

//�жϺ���
void TIM4_IRQHandler(void)
{
	if (TIM_GetITStatus(TIM4, TIM_IT_Update) == SET)
	{
		FPS = FPS_Counter;
		FPS_Counter = 0;
		
		TIM_ClearITPendingBit(TIM4, TIM_IT_Update);
	}
}
